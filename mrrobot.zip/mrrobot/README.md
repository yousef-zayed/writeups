# [Pickle Rick — TryHackMe](https://tryhackme.com/room/mrrobot)

**Difficulty:** Medium

**Category:** Web exploitation, RCE, Linux, Privilege Escalation

## Overview

Mr Robot is a challenge were you start the engagement with the web application and ends it as a root user in order to get the 3 hidden keys.

---

## 1. Reconnaissance

### Port Scan

Starting with a portscan using `nmap` with the following:

```bash
nmap -sV -sS -sC -p- -T5 -oN port_scan.txt <target>
```

*Full output in [port_scan.txt](./evidence/command_outputs/port_scan.txt).*

We got 3 services:
- HTTP port 80
- HTTPS port 443
- SSH port 22

I visited both webservers on ports 80 and 443 were serving the same content so I continued exploring on port 80.

### Directory Enumeration

Using `gobuster` with `common.txt` wordlist to brute-force hidden directory on the web:

```bash
gobuster -u <target> -w /path/to/common.txt -x js,php,html,txt,bak,xml -rt 100
```

*Full output in [initial_dir_enum.txt](./evidence/command_outputs/inital_dir_enum.txt)*

There was a lot of pages that returned true, but only few where useful. Also there was many pages with the scheme `wp-` something, which later I found out it was a naming convention for `wordpress`.

However, As I was enumerating and exploring while the tool was examining, each successful output it gave me I went to the browser and looked it up to try and get a deeper understanding to the app. The first output was `/0`, It didn't have much but it redirected me to some kind of a blog page. 

<img src='./evidence/screenshots/0.png'>

The second output I examined was `/atom`, I looked it up and it said `Just Another WordPress site`. Here, I knew I was dealing with `wordpress` I dont know what version but that's an information worth noting. 

<img src='./evidence/screenshots/atom.png'>

However, I knew it was inefficient to manually check each successful site as it could just like `/atom` another filler site that was made by accident or because of an automated script. So I waited for the tool to finish and note the intresting sites.

They were:

```text
/robots.txt
/license.txt
/readme.html
/login
/wp-admin
```

I was quite surprised to see that the `/robots.txt` wasn't suppressed, whoever upon visiting it I got 2 intresting pieces of information:
- The first key
- A custom dictionary

<img src='./evidence/screenshots/robots.png'>

I got the names, but no link or nothing. My first intuition was that they were a sub-page so I tried `/key-1-of-3.txt`.

<img src='./evidence/screenshots/key1.png'>

Here we got the first key. So I tried the dictionary `/fsocity.dic` and I was able to view it. 

<img src='./evidence/screenshots/fsocity_dic.png'>

I downloaded locally as I thought I might need it for any brute-force attack I could do on `/login`. 

```bash
wget http://<target>/fsocity.dic
```

I then visited `/license.txt`, which I got a real good piece of information

<img src='./evidence/screenshots/license1.png'>

<img src='./evidence/screenshots/license2.png'>

*Full output in [license.txt](./evidence/command_outputs/license.txt)*

At the end of the page there's a string of text, it looks gibbresh but the equal sign `=` at the end of the text gave me a feeling it might be a base65 encoding to some text. So I went to `CyberChef` to base64 decode the string, which I got a a whole `username:password` format credentials.

<img src='./evidence/screenshots/decoding_license.png'>

I then checked `/readme.html`, It has nothing useful but it was funny.

<img src='./evidence/screenshots/readme.png'>

However, now it was the time to try the credentials in `/login`.

## 2. Inital Access

Upon visiting `/login` I found it was a wordpress login page.

<img src='./evidence/screenshots/login.png'>

I tried the credentials we decoded from `/license.txt`, and it was successful and We also got wordpress admin priviliges.

*NOTE: Another approach to this is using the dictionary `fsocity.dic` to brute force it. I've seen multiple people use this approach but I didn't have to as the enumeration phase gave it to us.*

<img src='./evidence/screenshots/admin_access.png'>

<img src='./evidence/screenshots/admin_access_users.png'>

I actually took a lot of time to explore the page and see what can I do. I hit a wall, I didn't know what to do next. However, I found that the `Editor` in the `themes` menu was activated and it actually executed `php` code. 

<img src='./evidence/screenshots/themes_editor.png'>

I choose the `archive.php` file and used a [`php` reverse shell payload](https://github.com/pentestmonkey/php-reverse-shell/blob/master/php-reverse-shell.php). I started a listener on my machine, I pasted the payload and changed the IP address to my IP address and the port to the port the listener is listenning to. I then naviageted to `/wp-content/themes/twentyfifteen/archive.php` to request the file in order to the server to execute it. The server connected to my listener and now we successfully have a shell.

<img src='./evidence/screenshots/reverse_shell_access.png'>

## 3. Filesystem Enumeration

I enumerated the filesystem, starting with `/home` which I found two users:
- `robot`
- `ubunut`

The `ubunut` user didn't have anything useful. However, the `robot` user had 2 file:
- key-2-of-3.txt
- password.raw-md5

<img src='./evidence/screenshots/filesystem_enum.png'>

The primmission of both files was explicit, we can't read `key-2-of-3.txt` only the creator can but we can read `password.raw-md5`. 

*You can read the hash from [here](./evidence/command_outputs/robot_hash.txt)*

From the name and the content of the file we can see it's an `md5` hash of the password. So I used `john` along side with the dictionary we obtained `fsocity.dic` to crack the hash.

```bash
john --format=raw-md5 --wordlist=fsocity.dic robot_hash.txt
```

I got a password but when I tried to use it, it failed to authenticate meaning it wasn't the password.

<img src='./evidence/screenshots/failing_to_authenticate.png'>

So I went and I used [hashes.com](https://hashes.com/en/decrypt/hash) to crack the hash, which ironically enough gave me the same password but in all lowercase letters. When I tried to use it, I successfully got authenticated and authorised as `robot`. 

<img src='./evidence/screenshots/robot_access.png'>

We then can retrieve the second flag by reading it:

```bash
cat /home/robot/key-2-of-3.txt
```

## 4. Privilige Escalation

I then checked the `sudo` priviliges of `robot` and it was nothing, the user `robot` has no authority to run `sudo` on this machine. So instead I enumerated any files that may contain `setuid` with root binaries.

```bash 
find / -perm -4000 -type f 2>/dev/null
```

<img src='./evidence/screenshots/setuid_enumeration.png'>

The interesting output was `nmap`, as `nmap` has an interactive mode which can execute system commands, and the commands runs with the same privilige as the `nmap` process, which in this case is `root`. I ran `nmap` in interactive mode, I then checked for privilige and landed a bash shell on top of the interactive mode for easier usage. 

```bash
bash -i
```

<img src='./evidence/screenshots/nmap_interactive_mode.png'>

<img src='./evidence/screenshots/root_access.png'>

We can then retrieve the third key `key-3-of-3.txt` which is located in `/root`, and by that we finish the challenge and the attack chain as we managed to get root access to the machine. 

The root access can be further exploited/utilised to gain presistent access by adding private key to an `.ssh` directory, or by any other techniques.

## Attack Chain

```text
Reconnaissance
    ↓
Directory Enumeration
    ↓
Credential Discolsure
    ↓
CMS Admin Access
    ↓
Reverse Shell
    ↓
Lateral Privilige Escalation
    ↓
Vertical Privilige Escalation
```

## Key Takeaways

I need to be honest, there are multiple things that I didn't do right in this engagment, One of them being not mapping the CMS version to any CVEs. As I later discovered that the version of the CMS (WordPress) that the machine was running `WP 4.3.1` had a well known CVE `CVE-2021-34257` Check it at [cve.org](https://www.cve.org/CVERecord?id=CVE-2021-34257).

## Flags

Flags obtained during the challenge have been redacted from this write-up.

> TryHackMe flags and sensitive challenge credentials are intentionally omitted.
